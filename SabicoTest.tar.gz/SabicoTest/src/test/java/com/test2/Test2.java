package com.test2;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class Test2 {

	WebDriver driver;
	By cookieLocator = By.id("cn-close-notice");
	By avisoLocator = By.linkText("Avisos legales y políticas");
	By resultLocator = By.cssSelector("span.highlight1");
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/driver/geckodriver");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.sabico.com");
	}

	@Test
	public void aviso_searcher() {
		WebDriverWait wait = new WebDriverWait(driver, 7);
		
		WebElement cookie = driver.findElement(cookieLocator);
		cookie.click();
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(avisoLocator));
		WebElement aviso = driver.findElement(avisoLocator);
		aviso.click();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(resultLocator));
		
		System.out.println("La prueba ha finalizado con exito");
		
		assertTrue(driver.findElement(resultLocator).isDisplayed(), "Ha habido un error");
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
