package com.test5;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Test5 {

	WebDriver driver;
	By blogLocator = By.id("menu-item-3022");
	By blogSubLocator = By.linkText("¡Suscríbete a nuestro Blog!");
	By blogSubNowLocator = By.id("subscribenow");
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/driver/geckodriver");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.sabico.com");
	}

	@Test
	public void blog_searcher() {
		WebElement blog = driver.findElement(blogLocator);
		blog.click();
	
		WebDriverWait wait = new WebDriverWait(driver, 7);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(blogSubLocator));
		
		WebElement blogSub = driver.findElement(blogSubLocator);
		blogSub.click();
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(blogSubNowLocator));
		System.out.println("La prueba ha finalizado con exito");
		
		assertTrue(driver.findElement(blogSubNowLocator).isDisplayed(), "Ha habido un error");
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
