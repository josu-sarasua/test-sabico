package com.test3;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Test3 {

	WebDriver driver;
	By contactoLocator = By.id("menu-item-3025");
	By subLocator = By.id("menu-item-3104");
	By formLocator = By.cssSelector("span.highlight1");
	//By blogSubNowLocator = By.id("subscribenow");
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/driver/geckodriver");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.sabico.com");
	}

	@Test
	public void contacto_searcher() {
		WebElement menu = driver.findElement(contactoLocator);
		WebElement sub = driver.findElement(subLocator);
		
		Actions action = new Actions(driver);
		action.moveToElement(menu).perform();
		
		WebDriverWait wait = new WebDriverWait(driver, 7);
		wait.until(ExpectedConditions.visibilityOf(sub));
		
		sub.click();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(formLocator));
		
		System.out.println("La prueba ha finalizado con exito");
		
		assertTrue(driver.findElement(formLocator).isDisplayed(), "Ha habido un error");
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

}